# NFS4 Silent Scanner ASI

Read-only, **32-bit Windows** ASI plugin for `nfs4.exe` and `nfsgame.exe`.
It runs inside the game, without a window or console, and samples the NFS4
memory layout already used by `capture/src/main.go`. It does not patch or hook
game memory. Optional uploads use the configured HTTPS Race Capture API.

## Install

1. Close NFS4.
2. Use your existing **32-bit ASI loader**. Copy both files from `bin/`
   (`NFS4SilentScanner.asi` and `NFS4SilentScanner.ini`) into the same folder
   that your loader scans. Some loaders scan the game folder; others scan
   `scripts/` or `plugins/`. An ASI loader is required and is not bundled.
3. Launch the game normally. The plugin writes to
   `NFS4SilentScanner-Logs/` beside the ASI. That folder must be writable.
4. To stop sampling, set `[Scanner] Enabled=0`. To uninstall, close the game
   and remove the ASI and INI. Hot unloading is not supported: the worker pins
   the module until game exit to avoid executing unloaded code.

The INI filename is always `NFS4SilentScanner.ini`, beside the plugin, not
relative to the game's working directory. Settings reload on each poll;
`StartupDelayMilliseconds` applies only at startup. No UI error dialogs are
displayed if logging is disabled or the output directory cannot be written.

## Track changes and diagnostic logs

Race settings freeze at the first completed local result. Remote humans can
continue finishing against those settings. Once stable, the complete capture
also freezes for upload retries. Changing the track, laps, or other menu options
cannot relabel that result. Two readable samples with cleared lap splits and
completed-lap count (and a zero or grid timer) are required before the next race.

Set `[Debug] Enabled=1` to record `NFS4SilentScanner-Logs/api-debug.log` beside
the ASI. `stage=capture_settings_frozen` records the captured track, laps, and
ticks; `stage=stale_result_guard` records ignored menu track changes;
`stage=result_reset reason=confirmed_clear` identifies the next-race boundary.
`races.csv` contains accepted local captures, and response lines contain the
server request ID. Include rotated `.1` files when investigating an older race.
The CSV keeps `TotalTicks` and `BestLapTicks` and adds readable `TotalTime` and
`BestLapTime` values in `HH:MM:SS.mmm` format, plus `ConnectionType` (`Online`
or `Offline`). When an older CSV header is found, it is preserved as
`races-legacy-<UTC timestamp>.csv` and a new-format `races.csv` is started.
Race uploads store the same connection classification on the website. Career,
tournament, knockout, and single events are marked `Offline` unless the game
reports the TCP/IP session state.

## Configuration

`[Player] Persona` is sent as the uploader identity as well as the local racer
name; blank uses the in-game name. In TCP, local slot 0 submits as host and other
slots as guests. Guest uploads are provisional until a matching host upload
becomes primary. Each submission remains available to website administrators.

TCP capture waits for every detected human in a car/result slot to finish and
for their totals and positions to stabilize. A leftover name in an otherwise
empty slot does not count as a racer. A later-place human with a shorter total
than an earlier-place human keeps capture waiting. `Wild 1` is an AI name;
unfinished AI does not block human results. There is no timeout that submits
unfinished human results.

| Section / key | Default | Behavior |
|---|---:|---|
| Scanner / Enabled | 1 | 0 pauses memory reads and logging |
| Scanner / PollMilliseconds | 1000 | Sample interval, clamped to 100–60000 ms |
| Scanner / StartupDelayMilliseconds | 3000 | Initial delay, clamped to 0–60000 ms |
| Logging / Snapshots | 1 | Write `snapshots.jsonl` |
| Logging / OnlyOnChange | 1 | Suppress identical snapshots; timestamp excluded from comparison |
| Logging / MaxFileMB | 16 | Per-file rotation threshold, clamped to 1–256 MiB |
| Logging / RaceCSV | 1 | Append completed, stable races to `races.csv` |
| TrackNames / `<TrackID>` | empty | Optional display-name override for stock DLC TrackIDs not in the built-in list |
| Debug / Enabled | 0 | Write `debug.log`: PID, module base, poll interval, read failures |
| Debug / IncludeResultHex | 0 | Include each slot's 0x91-byte result block in snapshots; requires Debug.Enabled |
| Upload / Enabled | 1 | Upload captured human results; TCP host sessions include every occupied slot as human |
| Upload / ApiURL | Race Capture ingest URL | Must be an HTTPS URL |
| Upload / ApiKey | empty | Uses the baked-in public game key; a personal key overrides it |
| Upload / CooldownSeconds | 60 | Minimum delay between successful uploads; 0 disables it |
| Replay / Enabled | 0 | Watch newly saved `.rp4` and `.gst` files and attach them after a race upload |
| Replay / SaveFolder | `savedata\saves` | Folder relative to `nfs4.exe`, or an absolute Windows path |
| Replay / ApiURL | Race Capture replay URL | HTTPS multipart attachment endpoint |
| Upload / StableSamples | 3 | Consecutive complete result samples, clamped to 2–30 |

Each log has at most one `.1` backup. A file can exceed the threshold by one
record before rotation on the next write. Files are closed after each write.
If snapshots, debug, race CSV, race uploads and replay watching are all disabled,
the scanner skips memory sampling.

Website uploads use the baked-in public game key when `ApiKey` is blank; no account is required. Set `[Upload] Enabled=1` to enable them. A personal profile key in `ApiKey` owns future uploads and is authoritative: rejected personal keys never fall back to public uploads. To attach saved
replays and ghosts, also set `[Replay] Enabled=1`. The watcher waits until a
new or changed `.rp4`/`.gst` file is stable, then attaches it to its pending
capture after the race upload is accepted. Files discovered while a capture is
waiting are held until the server returns that capture's race ID, so they cannot
attach to the previously uploaded race. Retries retain the race association.
Returning to the menu or resetting game results keeps the accepted race ID so
replays saved just after finishing can still attach. The watcher scans only the
configured save folder.
With debugging enabled, `api-debug.log` includes watcher state, discovery,
file-read/sanitization errors and attachment HTTP results. Files older than the
current game launch are skipped; the watcher and race association are in memory.
Files are
limited to 20 MiB; invalid or ambiguous embedded credential fields prevent
upload. Credential fields are replaced in the upload copy, leaving the original
unchanged. An optional personal key is stored as plain text in this local INI, so keep that file
private and revoke the key if you share or lose it.

For a stock DLC track without a `mixer.ini` name, add its numeric ID under
`[TrackNames]`, for example `19=Example Stock DLC Track`. The name is sent with
the capture and used in local race logs. Mixer names remain preferred when
available.

Set `[Player] Persona` to the public persona used for local-player website
results. Blank falls back to the in-game name. `[Upload] CooldownSeconds`
defaults to 60 and limits successful uploads; failed requests may retry after
the normal retry interval.

Race uploads are JSON common-schema posts to the existing HTTPS API; the local
CSV is not uploaded. A recognized single-player, Career or TCP-host session is
required. Single-player and Career submit only the local player; TCP host
sessions classify the known opponent names as AI and leave other occupied
slots as human. Other roster rows in
non-TCP sessions are written to CSV as `Other`. Failed race and attachment
requests retry at most once every 30 seconds.

Each race upload hashes the running game executable, `.viv` files under
`Data/Cars`, and non-`.zip` files under `Data/Tracks`, matching the desktop
scanner's NFS4 file selection. Evidence includes each relative logical path,
filename, SHA-256 and byte count. The ASI car catalog maps folder codes to car
names and base classes before upload; upgrade levels 1–3 add `+` to the class.
Collision reads `nfs4.exe+4527C4` (`0` on, `1` off); damage reads
`+3C4CC0` (`0` on, `1` visual, `2` physical, `3` off). In Hot Pursuit,
traffic is reported on regardless of the raw traffic flag. Hot Pursuit uploads
include named non-local racer slots as AI; unfinished AI totals are placed after
the human using a 15-second-per-lap offset and 5-second rank steps, and missing
AI speeds use the human speed minus 20 mph.
The pursuit assist flag is read from `+3C4CC4`; the Hot Pursuit subtype is read
from `+3C4CA4`, and opponent selection from `+1B8194`.
Overall assistance is on when damage is visual only (`1`), physical only (`2`),
or off (`3`), or braking, collision recovery, traction control, or pursuit
assistance equals `1`. Full damage (`0`) alone does not enable assistance.

## Output and interpretation

With `[Debug] Enabled=1`, `api-debug.log` records the capture gate (including
session bytes and incomplete results), stabilization, hashing duration, request
send, HTTP status, Windows transport error code, acceptance and retry interval.
`stage=sent` means WinHTTP sent the request; `accepted=1` requires a successful
HTTP response containing a race ID. Hashing and network work run on the scanner
worker, so a slow attempt also delays sampling. Retries still require the finished
result to remain in game memory; there is no persistent upload queue.

The website ingest and replay endpoints write `NFS_API` JSON entries to the
hosting PHP error log. Each request returns `X-NFS-Request-ID`, also recorded by
the ASI. Stages cover bootstrap, authentication, decoding, normalization, database
locks, commit, response and shutdown. A start without a response identifies an
interrupted request; fatal shutdown entries identify the PHP file and line.
Credentials and request/response bodies are not logged. Deploy
`website/_private/app/api_debug.php`, `website/_private/app/api.php`, and both
`website/api/v1/ingest.php` and `replay.php` together to enable server tracing.

Each JSON line contains a UTC timestamp, process ID and `snapshot`:

The NFS4 snapshot also includes `track_id_validator`, read from
`nfs4.exe+0x3C4CE4`, and `track_id_matches`, which is true when it agrees with
the existing `track_id` read at `nfs4.exe+0x343290` (null if either read
fails). Both values are diagnostic; the existing `track_id` remains the one
used for capture. The snapshot also includes `track_folder`, read as a 63-byte
null-terminated string from `nfs4.exe+0x341A70` (the game's TrackFolder
buffer). The scanner checks
`<game folder>\Data\Tracks\<track_folder>\mixer.ini`; a non-empty `Name=` in
`[TrackData]` becomes `track_mixer_name` and the effective `track_name` in
snapshots, race CSV, and upload race metadata. Stock mixer files without a
`Name=` use the known folder-to-stock-name map (including `home` → Hometown),
independent of Track ID; unknown folders fall back to the existing track ID
label. Enable `[Logging] Snapshots=1` to record these values in
`snapshots.jsonl`.

- Session bytes, both mode bytes, derived Career and Hot Pursuit flags.
  Career takes priority. Mode 4 includes both test drive and Career.
- Local slot, track ID, configured laps, race family/difficulty/signature,
  knockout counters and raw race settings.
- All eight slots: name, car code, upgrade, position, completed laps,
  total/lap ticks, raw speed, converted mph and ticket fields.
- `finish_candidate` uses the scanner's lap-count/lap-sum checks. It is a
  single sample, **not** a stabilized completed-race notification.
- Failed scalar reads are `null`; unreadable result blocks have
  `result_readable:false`. `read_failures` counts failures per snapshot.

Snapshot logging preserves raw positions (including zero), empty slots and
partial times for debugging. It does not synthesize AI results, rank DNFs or
infer AI identities. Car codes are resolved using the bundled game catalog.
Hot Pursuit uploads include `tickets_issued` from each slot's `+0x94` counter
and `tickets_received` accumulated from rising edges of its `-0x21B` pulse.
Held pulses count once; police unit names do not accumulate received tickets.
Counters reset when the local timer/lap count restarts, the track changes, or
the session leaves racing; a changed participant name resets that slot.
Snapshots include both totals and raw values. A 1000 ms poll may miss short pulses.
Race CSV and upload run only after the local player has a complete, consistent
lap/time/position record for several consecutive samples. Top speed is accepted
only below 250 mph and after `StableSamples` consecutive readings within 1 mph;
unstable or implausible readings are ignored, and upload waits for finished
human racers' speed readings to stabilize. Completed race results and settings
are frozen as soon as the finish is detected, so the game can clear its result
screen while speed samples continue to stabilize. There is no fixed finish
delay; upload proceeds once all captured human speeds are stable.

Timer values are the existing scanner's UInt16 ticks at 64 Hz. Memory is
sampled sequentially while the game runs, so a snapshot is not atomic. Player
name bytes outside ASCII are escaped as byte values in JSON. Optional hex
logging is limited to result blocks, not arbitrary memory or credentials.

Offsets are relative to the game module's actual base (existing absolute
scanner addresses minus `0x400000`), including:

| Value | Module-relative address |
|---|---|
| Session A / B | `+341418` / `+341420` (TCP/IP states include 20/21 and 35/36) |
| Mode A / B | `+1B819C` / `+3C4BF4` |
| Difficulty | `+3C4C9C` (`0=Amateur`, `1=Pro`, `2=Champion`) |
| Track ID validator | `+3C4CE4` |
| Track folder | `+341A70` |
| Local slot | `+3432D0` |
| Player-name table | `+3C4D64`, stride `0x70` |
| Result slot 0 | `+261FB8`, stride `0xAD4`, eight slots |

Raw `mode_a`, `mode_b`, `difficulty_raw`, `track_id_validator`, and
`track_folder` are included in debug snapshots and uploaded race metadata. Mode
values are `0=Single Race`, `1=Tournament`, `2=Knockout`, `3=Hot Pursuit`, and
`4=Test Drive/Career`; the mode slots, rather than lap-count inference, select
the race mode.

Only the existing NFS4 memory layout is supported; executable names alone do
not guarantee layout compatibility. Failed reads are handled without direct
pointer dereferences. Validate captures against the game after installing.

## Build and test

First follow [public API release setup](PUBLIC-API.md) to create and save the
NFS4 public game key. Builds verify its scope with the website before embedding
it, and refresh both the ASI and ZIP. Racers leave `ApiKey` blank.

The build uses portable Zig 0.14.1 as a C compiler; no Visual C++ runtime
installation or Go runtime is required by the plugin.

Download the Windows x64 compiler from
https://ziglang.org/download/0.14.1/zig-x86_64-windows-0.14.1.zip
and verify its SHA-256 against the official https://ziglang.org/download/index.json:

`554f5378228923ffd558eac35e21af020c73789d87afeabf4bfd16f2e6feed2c`

Extract under `.tools/`, then run from the repository root:

```powershell
./capture/ASI/build.ps1
./capture/ASI/test.ps1
```

Both scripts accept `-Zig C:/path/to/zig.exe`. The compiler and caches stay
local and are ignored by Git. `build.ps1` produces the ASI and copies the
default INI into `bin/`. It verifies the output is an x86 DLL.

The test loads the actual ASI into a synthetic x86 `nfs4.exe` process with
fixture memory. It checks decoded data, Career/Hot Pursuit transitions,
unreadable pages, valid JSON, debug logging, duplicate suppression, rotation,
disabled scanning and rejection of unrelated processes.
It does not launch or modify your game. Live NFS4 validation is still needed.

Windows API references: [DLL initialization guidance](https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-best-practices)
and [ReadProcessMemory](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-readprocessmemory).
